<?php
/**
 * SMTP credentials for the contact form.
 *
 * KEEP THIS FILE PRIVATE. Fill in the real values directly on the server.
 * Because this is a .php file, the web server executes it rather than serving
 * its text, so the credentials are never exposed to visitors.
 *
 * How to get a Gmail App Password:
 *   1. Turn on 2-Step Verification: https://myaccount.google.com/security
 *   2. Create an App Password: https://myaccount.google.com/apppasswords
 *      (pick "Mail" / "Other"). Google shows a 16-character code.
 *   3. Paste it below as 'password' WITHOUT the spaces.
 */
return [
    'host'      => 'smtp.gmail.com',
    'port'      => 587,
    'username'  => 'danalee.seattle@gmail.com', // the Gmail you log into
    'password'  => 'nkqvieeisiqwkceb',           // Google App Password, no spaces
    'from'      => 'danalee.seattle@gmail.com',  // must match the Gmail above
    'from_name' => 'hellodanalee.com contact form',
    'to'        => 'danalee.seattle@gmail.com',      // where messages are delivered
];
